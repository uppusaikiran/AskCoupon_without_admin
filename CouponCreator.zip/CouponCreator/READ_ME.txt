THANK YOU FOR YOUR PURCHASE!
============================

Please read the following carefully.

LICENSE / TERMS:

To confirm your master resell rights to this product, you must subscribe to our list at:
www.cathyedwards.com/go/CouponCreator

This will allow you to:

* sell this product to your list for any price
* allow your customers to sell it to their list for any price
* allow you or your customers to give the product away for the optin
* allow you or your customers to include the product in a membership site


INSTRUCTIONS

To receive instructions on how to use this product, go to:
www.cathyedwards.com/go/CouponCreator